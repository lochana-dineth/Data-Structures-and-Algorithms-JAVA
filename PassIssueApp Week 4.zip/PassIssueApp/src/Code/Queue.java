/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;

/**
 *
 * @author sa22521620
 */
public class Queue {
     private int maxSize;
     private GamePass queueArray[];
     private int front;
     private int rear;
     private int nItems;
    
    public Queue(int s)
    {
        this.maxSize = s; 
        queueArray = new GamePass [maxSize];
        rear = -1;
        front = 0;
        nItems = 0;
    }
    
    public boolean isEmpty()
    {
        return(nItems==0);
    }
    
    public boolean isFull()
    {
       return(nItems==maxSize);
    }
    
    public void enqueue( GamePass gp)
    {
        if(isFull())
        {
            System.out.println("Queue is Full");
        }
        else
        {
            if(rear ==maxSize-1)
            {
                rear = -1;
            }
            rear = rear +1;
            queueArray[rear]=gp;
            
            nItems = nItems+1;
            
        }
        
    }
    
    public GamePass dequeue()
    {
        if(isEmpty())
        {
            return null;
        }
        else
        {
            if(front ==maxSize)
            {
                front = 0;
            }
            nItems=nItems -1;
            front = front +1;
            return queueArray[front-1];
            
        }
        
        
    }
    public GamePass peek()
    {
        if(isEmpty())
        {
            return null;
        }
        else
        {
            return queueArray[front];
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;

/**
 *
 * @author sa22521620
 */
public class GamePass {
    public int passNumber;
    public String playerName;
    
    
    public GamePass (int passNumber, String playerName)
    {
        this.passNumber = passNumber;
        this.playerName = playerName;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;

/**
 *
 * @author sa22521620
 */
public class Stack {
    
     int maxsize;
     Box stackArray[]; // to hold Box objects
     int top;

    public Stack(int maxSize) {
        this.maxsize = maxSize;
        this.stackArray = new Box[maxSize];
        this.top = -1;
        
    }


    
   
    public void push(Box b)
    {
        if(top == (maxsize -1))
        {
            System.out.println("Box is full");
        }
        else
        {
            top = top + 1;
            stackArray[top] = b;
        }    
           
    }
    
    public Box pop()
    {
        if (top == -1)
        {
            return null;
        }    
        else
        {
          top = top -1;
          return stackArray[top + 1];
        }
    }
    
    public Box peek()
    {
        if (top == -1)
        {
            return null;
        }
        else
        {
            return stackArray[top];
        }
    }
    
 
  
    
    public boolean isEmpty()
    {
        if(top == -1)
        {
            return true;
        }
        else
        {
            return false;
        }    
    }
    
    public boolean isFull()
    {
        if(top == maxsize -1)
        {
            return true;
        }
        else
        {
            return false;
        }   
    }
     
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;

/**
 *
 * @author sa22521620
 */
public class Box {
    private String boxCode;
    private double weight;
    
    //Creating Constructor

    public Box(String boxCode, double weight) {
        this.boxCode = boxCode;
        this.weight = weight;
    }

    public String getBoxCode() {
        return boxCode;
    }

    public double getWeight() {
        return weight;
    }
    
}

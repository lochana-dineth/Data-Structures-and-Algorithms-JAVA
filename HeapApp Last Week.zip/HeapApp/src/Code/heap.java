/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;

/**
 *
 * @author sa22521620
 */
public class heap {
    member heapArray[];
    int maxSize;
    int heapSize;
   
    
    public heap(int maxSize)
    {
        this.maxSize = maxSize;
        heapArray = new member[maxSize];
        int heapsize =0;
    }
    
    public boolean insert(member m)
    {
        if(heapSize == maxSize){
        return false;
        }
        else
        {
        heapArray [heapSize] = m;
        trickleUp(heapSize++);
        return true;
        }
         
    }
    
    public member getRoot()
    {
         member root = heapArray[0];
         return root;
    }
    
    public void trickleUp(int index)
    {
        int parent = (index-1)/2;
        member bottom = heapArray[index];
        while(index > 0 && heapArray[parent].getNumber()>bottom.getNumber())
        {
        heapArray[index] = heapArray[parent];
        index = parent;
        parent = (parent-1)/2;
        }
        heapArray[index] = bottom;
    }
    
    public member remove()
    {
        member root = heapArray[0];
        heapArray[0] = heapArray[--heapSize];
        trickleDown(0);
        return root;
    }
    
    public void trickleDown(int index)
    {
        
        
        int largerChild;
        member top = heapArray[index];
        while(index < heapSize/2)
        {
        int leftChild = 2*index+1;
        int rightChild = 2*index+2;
        if(rightChild < heapSize && heapArray[leftChild].getNumber()>heapArray[rightChild].getNumber())
        {
        largerChild = rightChild; }
        else{
        largerChild = leftChild; }
        if(top.getNumber() <= heapArray[largerChild].getNumber()){ break; }
        heapArray[index] = heapArray[largerChild];
        index = largerChild;
        }
        heapArray[index] = top;

    } 
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;

/**
 *
 * @author sa22521620
 */
public class Node {
 private String acronym; // the key
 private String meaning;
 public Node leftChild;
 public Node rightChild;
 
 public Node(String acronym, String meaning)
 {
     this.acronym = acronym;
     this.meaning = meaning;
     leftChild = null;
     rightChild = null;
 }
 
 public String getAcronym()
 {
     return acronym;
 }
 
 public String getMeaning()
 {
     return meaning;
 }
 
 
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;

/**
 *
 * @author sa22521620
 */
public class Puppy {

    private int cageNo;
    private String name;
    public String gender;
    public boolean vaccinated;

    //Creating Consctuctor
    public Puppy(int cageNo, String name, String gender) {
        this.cageNo = cageNo;
        this.name = name;
        this.gender = gender;
        vaccinated = false; // We have to add the default value ourselves.
    }

    public int getCageNo() {
        return cageNo;
    }

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public boolean isVaccinated() {
        return vaccinated;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;
import java.util.*;
/**
 *
 * @author sa22521620
 */

 public class HashTable
 {

    private Flower flowerList[];
    private int arraySize;
    
    public HashTable(int s)
    {
        flowerList = new Flower[s];
        arraySize = s;
   
    }
    
    private int hashFunction(int key)
    {
     return key % arraySize; 
    }
 
    public void insert(String f, String m)
    {
        int key =0;
        for (int i=0; i<f.length(); i++)
        {
            key += (int) f.charAt(i);
        }
        
        int hashval = hashFunction (key);
         while(flowerList[hashval] != null)
         {
         ++hashval;
         hashval %= arraySize;
         }
         flowerList[hashval] = new Flower(f,m);
    }
 
    public Flower delete(String k)
    {
        int key =0;
        for (int i=0; i<k.length(); i++)
        {
            key += (int) k.charAt(i);
        }
        
        int hashval = hashFunction(key);
        
        if (flowerList[hashval].getFlowerName().equalsIgnoreCase(k) )
        {
          flowerList[hashval] = new Flower("0","0");
          return flowerList[hashval];
        }
        else
        {
          return null;
        }
        
    }
 
    public Flower find(String k)
    {
        
        int key =0;
        for (int i=0; i<k.length(); i++)
        {
            key += (int) k.charAt(i);
        }
        
        int hashval = hashFunction(key);
        
        if (flowerList[hashval].getFlowerName().equalsIgnoreCase(k) )
        {
          return flowerList[hashval];
        }
        else
        {
          return null;
        }
        
   
    }

 

}
    


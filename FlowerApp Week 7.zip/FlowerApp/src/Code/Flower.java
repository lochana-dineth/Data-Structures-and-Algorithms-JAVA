/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;

/**
 *
 * @author sa22521620
 */
public class Flower {
    private String flowerName;
    private String meaning;

    public Flower(String flowerName, String meaning)
    { 
        this.flowerName = flowerName;
        this.meaning = meaning;
    }
    public String getFlowerName()
    {
        return flowerName;
    }
    
    public String getMeaning() 
    {
        return meaning;
    }

}

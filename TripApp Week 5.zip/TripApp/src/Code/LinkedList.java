/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;
import Code.*;

/**
 *
 * @author Gayana Fernando
 */
public class LinkedList {
    
    private Link first;
    
    public void LinkList()
    {
        first = null;
    }
    
    public Link getFirst() //return first
    {
        return first;
    }
    
    public boolean isEmpty()
    {
        if (first == null)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public void insertFirst(int no,String d, String p)
    {
        Link linkobj = new Link(no,d,p,null); //check this
        linkobj.next = first;
        first = linkobj;
        
    }
    
    public void insertLast(int no,String d, String p)
    {
        Link linkobj = new Link(no,d,p,null);
        linkobj.next = null;
        
        Link c =first;
        Link q = c;
        
        if(isEmpty())
        {
            first = linkobj;
        }
        else
        {
            while(c.next != null)
            {
                q = c;
                c = c.next;
            }
            
            q.next = linkobj;
            
        }
        
    }
    
    public void deleteFirst()
    {
        first = first.next;
    }
    
    public void insertBefore(int key, int no,String d, String p)
    {
        
        Link linkobj = new Link(no,d,p,null);
        linkobj.next = null;
        
        Link c =first;
        Link q = c;
        
         if(isEmpty())
        {
            first = linkobj;
        }
         else
        {
            while(c.next != null)
            {
                q = c;
                c = c.next;
                
                if(c.getDestinationNo() == key)
                {
                    q.next = linkobj;
                    linkobj.next = c;
                }
                
            }
            
        } 
        
    }
    
    //Key is the destination number of the existing destination
    public Link find(int no)
    { 
               
        
        Link c =first;
        Link q = c;
        
         if(isEmpty())
        {
            return null;
        }
         else
        {
            while(c.next != null)
            {
                q = c;
                c = c.next;
                
                if(q.getDestinationNo() == no)
                {
                    return q;
                }    
                
            }
            
            return null;
            
        } 
        
        
        
    }
    
    public Link delete(int no)
    {
   
        Link c =first;
        Link q = c;
        
         if(isEmpty())
        {
            return null;
        }
         else
        {
            while(c.next != null)
            {
                q = c;
                c = c.next;
                
                if(q.getDestinationNo() == no)
                {
                    q.next = c;
                    
                }
                
                
            }
            
            return null;
            
        } 
    }
   
}

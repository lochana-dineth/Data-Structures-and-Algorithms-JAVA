/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;

/**
 *
 * @author Gayana Fernando
 */
public class Link {
    
    private int destinationNo; // unique
    private String description;
    private String photo;
    public Link next;

    public Link(int destinationNo, String description, String photo, Link next) {
        this.destinationNo = destinationNo;
        this.description = description;
        this.photo = photo;
        this.next = next;
    }

    public int getDestinationNo() {
        return destinationNo;
    }

    public String getDescription() {
        return description;
    }

    public String getPhoto() {
        return photo;
    }

    

}
